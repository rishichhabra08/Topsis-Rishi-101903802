# Topsis-Rishi-101903802
 it is designed to provide a user-friendly graphical interface to solve large MCDM problems using TOPSIS

## Installation
```pip install Topsis-Rishi-101903802```

## How to use it?
Open terminal and type topsis and then enter details

## License

© 2022 Rishi Chhabra

This repository is licensed under the MIT license. See LICENSE for details.